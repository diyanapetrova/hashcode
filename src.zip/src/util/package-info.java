/** This package provides easy use of some common operations. */
package util;
